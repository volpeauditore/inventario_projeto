<?php
include '../../conexao.php'; // Conexão com o banco de dados

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_item = $_POST['id_item'];
    $data = $_POST['data'];
    $descricao = $_POST['descricao'];
    $responsavel = $_POST['responsavel'];
    $status_apos_manutencao = $_POST['status_apos_manutencao'];
    $comentarios = $_POST['comentarios'];

    // Inserir no banco de dados
    $query = "INSERT INTO manutencao (id_item, data, descricao, responsavel, status_apos_manutencao, comentarios) 
              VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("isssss", $id_item, $data, $descricao, $responsavel, $status_apos_manutencao, $comentarios);
    $stmt->execute();

    // Redirecionar de volta para a página do item
    header("Location: item.php?id=$id_item");
    exit();
}
?>
