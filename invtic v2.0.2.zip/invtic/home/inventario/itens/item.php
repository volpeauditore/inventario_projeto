<?php
include '../../conexao.php'; // Conexão com o banco de dados

// Habilitar exibição de erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Verificar se a conexão está funcionando
if (!$conn) {
    die("Erro de conexão: " . mysqli_connect_error());
}

// Obter o ID do item da URL
$item_id = $_GET['id'];

// Consultar as informações do item
$query_item = "SELECT * FROM inventario WHERE id = ?";
$stmt_item = $conn->prepare($query_item);
if ($stmt_item === false) {
    die("Erro ao preparar a consulta: " . $conn->error);
}

$stmt_item->bind_param("i", $item_id);
$stmt_item->execute();
$result_item = $stmt_item->get_result();
$item = $result_item->fetch_assoc();

// Consultar o histórico de manutenções
$query_manutencao = "SELECT * FROM manutencao WHERE id_item = ? ORDER BY data DESC";
$stmt_manutencao = $conn->prepare($query_manutencao);
if ($stmt_manutencao === false) {
    die("Erro ao preparar a consulta de manutenção: " . $conn->error);
}

$stmt_manutencao->bind_param("i", $item_id);
$stmt_manutencao->execute();
$result_manutencao = $stmt_manutencao->get_result();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do Item</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>

    <header>
        <nav>
            <img src="../../assets/logo/logo.png" alt="logo" class="logo">
            <h1>Sistema WEB de Inventário de TIC</h1>
            <ul>
                <li><a href="../../">Sair</a></li>
            </ul>
        </nav>
    </header>

    <main>

    <div class="container">
        <!-- Exibir as informações do item -->
        <h1>Detalhes do Item: <?php echo htmlspecialchars($item['tipo_equipamento']); ?></h1>
        <p><strong>ID do Item:</strong> <?php echo htmlspecialchars($item['id']); ?></p>
        <p><strong>Marca do item:</strong> <?php echo htmlspecialchars($item['marca']); ?></p>
        <p><strong>Modelo do item:</strong> <?php echo htmlspecialchars($item['modelo']); ?></p>
        <p><strong>Patrimônio:</strong> <?php echo htmlspecialchars($item['patrimonio']); ?></p>
        <p><strong>Status do item:</strong> <?php echo htmlspecialchars($item['status_item']); ?></p>
        <p><strong>Localização do item:</strong> <?php echo htmlspecialchars($item['setor']); ?></p>

        

    </div>
    <br>
        
    <div class="container">
        <!-- Formulário para adicionar manutenção -->
        <h2>Adicionar Nova Manutenção</h2>
        <form action="adicionar_manutencao.php" method="post">
            <input type="hidden" name="id_item" value="<?php echo $item_id; ?>">
            
            <label for="data">Data da Manutenção:</label>
            <input type="date" name="data" required>
            
            <label for="descricao">Descrição:</label>
            <textarea name="descricao" required></textarea>
            
            <label for="responsavel">Responsável:</label>
            <input type="text" name="responsavel" required>
            
            <label for="status_apos_manutencao">Status Após Manutenção:</label>
            <input type="text" name="status_apos_manutencao" required>
            
            <label for="comentarios">Comentários:</label>
            <textarea name="comentarios"></textarea>
            
            <button type="submit">Adicionar Manutenção</button>
        </form>
        
        </div>
        <br>

        <div class="container">
        <!-- Exibir o histórico de manutenções -->
        <h2>Histórico de Manutenções</h2>
        <?php if ($result_manutencao->num_rows > 0): ?>
            <table class="table-manutencao">
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Descrição</th>
                        <th>Responsável</th>
                        <th>Status após Manutenção</th>
                        <th>Comentários</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($manutencao = $result_manutencao->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($manutencao['data']); ?></td>
                            <td><?php echo htmlspecialchars($manutencao['descricao']); ?></td>
                            <td><?php echo htmlspecialchars($manutencao['responsavel']); ?></td>
                            <td><?php echo htmlspecialchars($manutencao['status_apos_manutencao']); ?></td>
                            <td><?php echo htmlspecialchars($manutencao['comentarios']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Não há manutenções registradas para este item.</p>
        <?php endif; ?>
        
        </div>
</body>

<footer>
            Inventário de TIC (InvTIC)
        </footer>
</html>
