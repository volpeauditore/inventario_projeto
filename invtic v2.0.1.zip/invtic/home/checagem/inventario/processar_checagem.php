<?php
include '../../conexao.php'; // Conexão com o banco de dados

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $setor = $_POST['setor'] ?? '';
    $status_item = $_POST['status_item'] ?? []; // Recebe o valor do select de status
    $conferido = $_POST['conferido'] ?? [];
    $excluir = $_POST['excluir'] ?? [];

    // Debug: Verificar se o status_item está correto
    var_dump($status_item); // Exibe os valores de status_item

    // Agrupa operações
    $erros = [];

    // Exclusão em massa
    if (!empty($excluir)) {
        $ids_para_excluir = implode(",", array_map('intval', $excluir));
        $sql_delete = "DELETE FROM inventario WHERE id IN ($ids_para_excluir)";
        
        if (!$conn->query($sql_delete)) {
            $erros[] = "Erro ao excluir itens: " . $conn->error;
        }
    }

    // Atualização em massa
    $sql_update = "UPDATE inventario SET status_item = ?, ultima_checagem = ? WHERE id = ?";
    $stmt_update = $conn->prepare($sql_update);

    if ($stmt_update) {
        foreach ($status_item as $id => $st) {
            if (!in_array($id, $excluir)) {
                $ultima_checagem = isset($conferido[$id]) ? date('Y-m-d H:i:s') : NULL;
                $stmt_update->bind_param("ssi", $st, $ultima_checagem, $id);
                
                if (!$stmt_update->execute()) {
                    $erros[] = "Erro ao atualizar o item ID $id: " . $stmt_update->error;
                }
            }
        }
        $stmt_update->close();
    } else {
        $erros[] = "Erro na preparação da atualização: " . $conn->error;
    }

    $conn->close();

    // Exibe mensagens de erro ou redireciona
    if (!empty($erros)) {
        echo "Ocorreram os seguintes erros:<br>" . implode("<br>", $erros);
    } else {
        header("Location: index.php?setor=" . urlencode($setor));
        exit;
    }
} else {
    echo "Método inválido.";
}
?>
